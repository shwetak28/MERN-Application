const express = require("express");
const app = express();
const mongoose = require("mongoose");
const dotenv = require("dotenv"); // Correct the way dotenv is required
dotenv.config();
const userRoute = require('./routes/userRoute');


//to  read data
app.use(express.json());

//Connect to mongodb database(locally)
mongoose
    .connect(process.env.URI, {
        useNewUrlParser: true,
        useUnifiedTopology: true
    })
    .then(() => {
        console.log("Connected successfully to MongoDB");
        const port = process.env.PORT || 8000;
        app.listen(port, (err) => {
            if (err) {
                console.log(err);
            } else {
                console.log(`Server is running successfully at port ${port}`);
            }
        });
    })
    .catch((error) => {
        console.log("Error connecting to MongoDB:", error);
    });

    app.use(userRoute);


 